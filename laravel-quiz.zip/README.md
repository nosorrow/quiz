Install:

composer install

npm install

