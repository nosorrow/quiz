<img src="{{url('img/quiz.jpg')}}" alt="logo" width="70">
